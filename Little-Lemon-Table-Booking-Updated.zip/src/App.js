import React, { useState } from "react";
import "./App.css";
import BookingForm from "./BookingForm";
import { getToday } from "./dateUtils";

const TIMES = [
  "12:00",
  "13:00",
  "14:00",
  "17:00",
  "18:00",
  "19:00",
  "20:00",
  "21:00",
];

// This function represents the restaurant's available-time lookup.
// It can later be connected to a real booking API.
export function fetchAvailableTimes(date) {
  if (!date) return TIMES;
  return [...TIMES];
}

export default function App() {
  // The parent component owns the available-times state.
  const [availableTimes, setAvailableTimes] = useState(() =>
    fetchAvailableTimes(getToday())
  );
  const [lastSelectedDate, setLastSelectedDate] = useState("");

  function updateTimes(date) {
    setLastSelectedDate(date);
    setAvailableTimes(fetchAvailableTimes(date));
  }

  return (
    <div className="app">
      <a className="skip-link" href="#booking">
        Skip to booking form
      </a>

      <header className="site-header">
        <a className="brand" href="#home" aria-label="Little Lemon home">
          <span className="brand-icon" aria-hidden="true">🍋</span>
          <span>Little Lemon</span>
        </a>

        <nav aria-label="Main navigation">
          <a href="#home">Home</a>
          <a href="#about">About</a>
          <a href="#booking">Reservations</a>
        </nav>
      </header>

      <main id="main-content">
        <section className="hero" id="home" aria-labelledby="hero-title">
          <div className="hero-content">
            <p className="eyebrow">WELCOME TO LITTLE LEMON</p>
            <h1 id="hero-title">Make time for something delicious.</h1>
            <p>
              Enjoy fresh Mediterranean flavors, warm hospitality,
              and a table waiting just for you.
            </p>
            <a className="primary-link" href="#booking">
              Reserve a table
            </a>
          </div>

          <div
            className="hero-art"
            role="img"
            aria-label="Fresh lemons and Mediterranean dining"
          >
            <span aria-hidden="true">🍋</span>
            <span aria-hidden="true">🥗</span>
            <span aria-hidden="true">🍋</span>
          </div>
        </section>

        <section className="about" id="about" aria-labelledby="about-title">
          <p className="eyebrow">GOOD FOOD, GOOD COMPANY</p>
          <h2 id="about-title">A little taste of the Mediterranean</h2>
          <p>
            At Little Lemon, we bring people together with fresh ingredients
            and a relaxed dining experience. Book your next visit below.
          </p>
        </section>

        <section
          className="booking-section"
          id="booking"
          aria-labelledby="booking-title"
        >
          <div className="booking-intro">
            <p className="eyebrow">YOUR TABLE IS WAITING</p>
            <h2 id="booking-title">Reserve a table</h2>
            <p>
              Complete the form to make your reservation request.
              Fields marked with * are required.
            </p>
          </div>

          <BookingForm
            availableTimes={availableTimes}
            onDateChange={updateTimes}
            lastSelectedDate={lastSelectedDate}
          />
        </section>
      </main>

      <footer className="site-footer">
        <p>🍋 Little Lemon Restaurant</p>
        <p>Fresh flavors. Memorable moments.</p>
        <p>© {new Date().getFullYear()} Little Lemon</p>
      </footer>
    </div>
  );
}
