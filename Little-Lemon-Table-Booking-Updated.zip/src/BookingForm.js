import React, { useState } from "react";
import { getToday } from "./dateUtils";

export function validateBooking(booking, availableTimes) {
  const errors = {};

  if (!booking.name.trim()) {
    errors.name = "Please enter your full name.";
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(booking.email.trim())) {
    errors.email = "Please enter a valid email address.";
  }

  if (!booking.date || booking.date < getToday()) {
    errors.date = "Please choose today or a future date.";
  }

  if (!availableTimes.includes(booking.time)) {
    errors.time = "Please select an available time.";
  }

  const guests = Number(booking.guests);
  if (!Number.isInteger(guests) || guests < 1 || guests > 10) {
    errors.guests = "Choose between 1 and 10 guests.";
  }

  return errors;
}

export default function BookingForm({
  availableTimes,
  onDateChange,
  lastSelectedDate,
}) {
  const [booking, setBooking] = useState({
    name: "",
    email: "",
    date: "",
    time: "",
    guests: "2",
    occasion: "None",
    requests: "",
  });
  const [errors, setErrors] = useState({});
  const [confirmation, setConfirmation] = useState("");

  function handleChange(event) {
    const { name, value } = event.target;

    setBooking((previous) => ({ ...previous, [name]: value }));
    setErrors((previous) => ({ ...previous, [name]: "" }));
    setConfirmation("");

    if (name === "date" && typeof onDateChange === "function") {
      onDateChange(value);
      // Keep the date update explicit; the parent owns availableTimes.
    }
  }

  function handleSubmit(event) {
    event.preventDefault();

    const validationErrors = validateBooking(booking, availableTimes);
    setErrors(validationErrors);
    setConfirmation("");

    if (Object.keys(validationErrors).length > 0) return;

    setConfirmation(
      `Thank you, ${booking.name.trim()}! Your booking request for ${booking.guests} guest(s) on ${booking.date} at ${booking.time} has been confirmed in this demo.`
    );
  }

  return (
    <form className="booking-form" onSubmit={handleSubmit} noValidate>
      <div className="form-field">
        <label htmlFor="name">Full name *</label>
        <input
          id="name"
          name="name"
          type="text"
          autoComplete="name"
          value={booking.name}
          onChange={handleChange}
          required
          aria-invalid={Boolean(errors.name)}
          aria-describedby={errors.name ? "name-error" : undefined}
        />
        {errors.name && <p className="error" id="name-error" role="alert">{errors.name}</p>}
      </div>

      <div className="form-field">
        <label htmlFor="email">Email address *</label>
        <input
          id="email"
          name="email"
          type="email"
          autoComplete="email"
          value={booking.email}
          onChange={handleChange}
          required
          aria-invalid={Boolean(errors.email)}
          aria-describedby={errors.email ? "email-error" : undefined}
        />
        {errors.email && <p className="error" id="email-error" role="alert">{errors.email}</p>}
      </div>

      <div className="form-field">
        <label htmlFor="date">Choose date *</label>
        <input
          id="date"
          name="date"
          type="date"
          min={getToday()}
          value={booking.date}
          onChange={handleChange}
          required
          aria-invalid={Boolean(errors.date)}
          aria-describedby={errors.date ? "date-error" : undefined}
        />
        {errors.date && <p className="error" id="date-error" role="alert">{errors.date}</p>}
      </div>

      <div className="form-field">
        <label htmlFor="time">Choose time *</label>
        <select
          id="time"
          name="time"
          value={booking.time}
          onChange={handleChange}
          required
          aria-invalid={Boolean(errors.time)}
          aria-describedby={errors.time ? "time-error" : undefined}
        >
          <option value="">Select a time</option>
          {availableTimes.map((time) => (
            <option key={time} value={time}>{time}</option>
          ))}
        </select>
        {errors.time && <p className="error" id="time-error" role="alert">{errors.time}</p>}
      </div>

      <div className="form-field">
        <label htmlFor="guests">Number of guests *</label>
        <select
          id="guests"
          name="guests"
          value={booking.guests}
          onChange={handleChange}
          required
          aria-invalid={Boolean(errors.guests)}
          aria-describedby={errors.guests ? "guests-error" : undefined}
        >
          {Array.from({ length: 10 }, (_, index) => index + 1).map((number) => (
            <option key={number} value={number}>
              {number} {number === 1 ? "guest" : "guests"}
            </option>
          ))}
        </select>
        {errors.guests && <p className="error" id="guests-error" role="alert">{errors.guests}</p>}
      </div>

      <div className="form-field">
        <label htmlFor="occasion">Occasion</label>
        <select
          id="occasion"
          name="occasion"
          value={booking.occasion}
          onChange={handleChange}
        >
          <option>None</option>
          <option>Birthday</option>
          <option>Anniversary</option>
          <option>Family gathering</option>
          <option>Business meal</option>
        </select>
      </div>

      <div className="form-field full-width">
        <label htmlFor="requests">Special requests (optional)</label>
        <textarea
          id="requests"
          name="requests"
          rows="3"
          maxLength="300"
          value={booking.requests}
          onChange={handleChange}
          placeholder="Let us know if you have any special requests."
        />
        <small>{booking.requests.length}/300 characters</small>
      </div>

      <button className="submit-button" type="submit">Confirm reservation</button>

      {confirmation && (
        <p className="success" role="status" aria-live="polite">{confirmation}</p>
      )}
      {lastSelectedDate && (
        <span className="visually-hidden" aria-live="polite">
          Available times updated for {lastSelectedDate}.
        </span>
      )}
    </form>
  );
}
