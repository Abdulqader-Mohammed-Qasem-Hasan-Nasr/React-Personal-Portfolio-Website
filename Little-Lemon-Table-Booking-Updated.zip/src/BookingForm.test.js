import React from "react";
import { act } from "react-dom/test-utils";
import { createRoot } from "react-dom/client";
import BookingForm, { validateBooking } from "./BookingForm";
import { getToday } from "./dateUtils";

const times = ["12:00", "13:00", "18:00"];

describe("validateBooking", () => {
  const validBooking = {
    name: "Abdulqader Nasr",
    email: "abdulqader@example.com",
    date: getToday(),
    time: "18:00",
    guests: "2",
    occasion: "None",
    requests: "",
  };

  test("returns no errors for valid booking data", () => {
    expect(validateBooking(validBooking, times)).toEqual({});
  });

  test("requires a name and a valid email", () => {
    const errors = validateBooking(
      { ...validBooking, name: "  ", email: "not-an-email" },
      times
    );
    expect(errors.name).toBeTruthy();
    expect(errors.email).toBeTruthy();
  });

  test("rejects past dates and unavailable times", () => {
    const errors = validateBooking(
      { ...validBooking, date: "2000-01-01", time: "15:00" },
      times
    );
    expect(errors.date).toBeTruthy();
    expect(errors.time).toBeTruthy();
  });

  test("limits guest count to 1 through 10", () => {
    const errors = validateBooking({ ...validBooking, guests: "11" }, times);
    expect(errors.guests).toBeTruthy();
  });
});

describe("BookingForm", () => {
  let container;
  let root;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
    root = createRoot(container);
  });

  afterEach(() => {
    act(() => root.unmount());
    container.remove();
  });

  test("renders the required booking fields and available time options", () => {
    act(() => {
      root.render(
        <BookingForm
          availableTimes={times}
          onDateChange={() => {}}
          lastSelectedDate=""
        />
      );
    });

    expect(container.querySelector('label[for="name"]')).not.toBeNull();
    expect(container.querySelector('input[type="email"]')).not.toBeNull();
    expect(container.querySelector('option[value="18:00"]')).not.toBeNull();
    expect(container.querySelector('button[type="submit"]')).not.toBeNull();
  });

  test("shows client-side validation errors after an invalid submission", () => {
    act(() => {
      root.render(
        <BookingForm
          availableTimes={times}
          onDateChange={() => {}}
          lastSelectedDate=""
        />
      );
    });

    act(() => {
      const form = container.querySelector("form");
      form.dispatchEvent(
        new Event("submit", { bubbles: true, cancelable: true })
      );
    });

    expect(container.textContent).toContain("Please enter your full name.");
    expect(container.textContent).toContain("Please enter a valid email address.");
  });
});
