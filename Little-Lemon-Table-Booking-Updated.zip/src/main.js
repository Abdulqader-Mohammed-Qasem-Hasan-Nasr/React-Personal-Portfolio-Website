// Compatibility entry for environments configured to load src/main.js.
// Create React root in src/index.js to avoid rendering the application twice.
import "./index";
