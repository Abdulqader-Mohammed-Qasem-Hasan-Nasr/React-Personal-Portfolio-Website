
import React, { useState } from "react";
import "./App.css";

const availableTimes = [
  "12:00",
  "13:00",
  "14:00",
  "17:00",
  "18:00",
  "19:00",
  "20:00",
  "21:00",
];

function getToday() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function validateBooking(booking) {
  const errors = {};

  if (!booking.name.trim()) {
    errors.name = "Please enter your full name.";
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(booking.email)) {
    errors.email = "Please enter a valid email address.";
  }

  if (!booking.date || booking.date < getToday()) {
    errors.date = "Please choose today or a future date.";
  }

  if (!availableTimes.includes(booking.time)) {
    errors.time = "Please select an available time.";
  }

  const guests = Number(booking.guests);

  if (!Number.isInteger(guests) || guests < 1 || guests > 10) {
    errors.guests = "Choose between 1 and 10 guests.";
  }

  return errors;
}

export default function App() {
  const [booking, setBooking] = useState({
    name: "",
    email: "",
    date: "",
    time: "",
    guests: "2",
    occasion: "None",
    requests: "",
  });

  const [errors, setErrors] = useState({});
  const [confirmation, setConfirmation] = useState("");

  function handleChange(event) {
    const { name, value } = event.target;

    setBooking((previous) => ({
      ...previous,
      [name]: value,
    }));

    setErrors((previous) => ({
      ...previous,
      [name]: "",
    }));

    setConfirmation("");
  }

  function handleSubmit(event) {
    event.preventDefault();

    const validationErrors = validateBooking(booking);
    setErrors(validationErrors);
    setConfirmation("");

    if (Object.keys(validationErrors).length > 0) {
      return;
    }

    setConfirmation(
      `Thank you, ${booking.name.trim()}! Your booking request for ${booking.guests} guest(s) on ${booking.date} at ${booking.time} has been confirmed in this demo.`
    );
  }

  return (
    <div className="app">
      <a className="skip-link" href="#booking">
        Skip to booking form
      </a>

      <header className="site-header">
        <a className="brand" href="#home" aria-label="Little Lemon home">
          <span className="brand-icon" aria-hidden="true">🍋</span>
          <span>Little Lemon</span>
        </a>

        <nav aria-label="Main navigation">
          <a href="#home">Home</a>
          <a href="#about">About</a>
          <a href="#booking">Reservations</a>
        </nav>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-content">
            <p className="eyebrow">WELCOME TO LITTLE LEMON</p>
            <h1>Make time for something delicious.</h1>
            <p>
              Enjoy fresh Mediterranean flavors, warm hospitality,
              and a table waiting just for you.
            </p>
            <a className="primary-link" href="#booking">
              Reserve a table
            </a>
          </div>

          <div className="hero-art" role="img" aria-label="Fresh lemons and Mediterranean dining">
            <span aria-hidden="true">🍋</span>
            <span aria-hidden="true">🥗</span>
            <span aria-hidden="true">🍋</span>
          </div>
        </section>

        <section className="about" id="about">
          <p className="eyebrow">GOOD FOOD, GOOD COMPANY</p>
          <h2>A little taste of the Mediterranean</h2>
          <p>
            At Little Lemon, we bring people together with fresh ingredients
            and a relaxed dining experience. Book your next visit below.
          </p>
        </section>

        <section className="booking-section" id="booking">
          <div className="booking-intro">
            <p className="eyebrow">YOUR TABLE IS WAITING</p>
            <h2>Reserve a table</h2>
            <p>
              Complete the form to make your reservation request.
              Fields marked with * are required.
            </p>
          </div>

          <form className="booking-form" onSubmit={handleSubmit} noValidate>
            <div className="form-field">
              <label htmlFor="name">Full name *</label>
              <input
                id="name"
                name="name"
                type="text"
                autoComplete="name"
                value={booking.name}
                onChange={handleChange}
                required
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? "name-error" : undefined}
              />
              {errors.name && (
                <p className="error" id="name-error" role="alert">
                  {errors.name}
                </p>
              )}
            </div>

            <div className="form-field">
              <label htmlFor="email">Email address *</label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                value={booking.email}
                onChange={handleChange}
                required
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? "email-error" : undefined}
              />
              {errors.email && (
                <p className="error" id="email-error" role="alert">
                  {errors.email}
                </p>
              )}
            </div>

            <div className="form-field">
              <label htmlFor="date">Choose date *</label>
              <input
                id="date"
                name="date"
                type="date"
                min={getToday()}
                value={booking.date}
                onChange={handleChange}
                required
                aria-invalid={Boolean(errors.date)}
                aria-describedby={errors.date ? "date-error" : undefined}
              />
              {errors.date && (
                <p className="error" id="date-error" role="alert">
                  {errors.date}
                </p>
              )}
            </div>

            <div className="form-field">
              <label htmlFor="time">Choose time *</label>
              <select
                id="time"
                name="time"
                value={booking.time}
                onChange={handleChange}
                required
                aria-invalid={Boolean(errors.time)}
                aria-describedby={errors.time ? "time-error" : undefined}
              >
                <option value="">Select a time</option>
                {availableTimes.map((time) => (
                  <option key={time} value={time}>
                    {time}
                  </option>
                ))}
              </select>
              {errors.time && (
                <p className="error" id="time-error" role="alert">
                  {errors.time}
                </p>
              )}
            </div>

            <div className="form-field">
              <label htmlFor="guests">Number of guests *</label>
              <select
                id="guests"
                name="guests"
                value={booking.guests}
                onChange={handleChange}
                required
                aria-invalid={Boolean(errors.guests)}
                aria-describedby={errors.guests ? "guests-error" : undefined}
              >
                {Array.from({ length: 10 }, (_, index) => index + 1).map(
                  (number) => (
                    <option key={number} value={number}>
                      {number} {number === 1 ? "guest" : "guests"}
                    </option>
                  )
                )}
              </select>
              {errors.guests && (
                <p className="error" id="guests-error" role="alert">
                  {errors.guests}
                </p>
              )}
            </div>

            <div className="form-field">
              <label htmlFor="occasion">Occasion</label>
              <select
                id="occasion"
                name="occasion"
                value={booking.occasion}
                onChange={handleChange}
              >
                <option>None</option>
                <option>Birthday</option>
                <option>Anniversary</option>
                <option>Family gathering</option>
                <option>Business meal</option>
              </select>
            </div>

            <div className="form-field full-width">
              <label htmlFor="requests">Special requests (optional)</label>
              <textarea
                id="requests"
                name="requests"
                rows="3"
                maxLength="300"
                value={booking.requests}
                onChange={handleChange}
                placeholder="Let us know if you have any special requests."
              />
              <small>{booking.requests.length}/300 characters</small>
            </div>

            <button className="submit-button" type="submit">
              Confirm reservation
            </button>

            {confirmation && (
              <p className="success" role="status" aria-live="polite">
                {confirmation}
              </p>
            )}
          </form>
        </section>
      </main>

      <footer className="site-footer">
        <p>🍋 Little Lemon Restaurant</p>
        <p>Fresh flavors. Memorable moments.</p>
        <p>© {new Date().getFullYear()} Little Lemon</p>
      </footer>
    </div>
  );
}

export { availableTimes, validateBooking };
