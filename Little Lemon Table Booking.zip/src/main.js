
import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.js";

const container = document.getElementById("root");

if (container) {
  createRoot(container).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
} else {
  console.error('Could not find an element with id="root". Check index.html.');
}
