
import React, { useEffect, useRef, useState } from "react";
import "./App.css";

const projects = [
  {
    number: "01",
    title: "Almoliki Grocery App",
    category: "Flutter · Mobile Development",
    description:
      "A grocery management application for organizing products, sales, purchases, and customer debts.",
    tags: ["Flutter", "Dart", "SQLite"],
  },
  {
    number: "02",
    title: "Student Management System",
    category: "Java · Application Development",
    description:
      "A student management system for adding, updating, viewing, and validating student records.",
    tags: ["Java", "OOP", "Validation"],
  },
  {
    number: "03",
    title: "Quiz Game",
    category: "Java · Programming",
    description:
      "A quiz application that presents multiple-choice questions and calculates the user's score.",
    tags: ["Java", "Scanner", "Control Flow"],
  },
  {
    number: "04",
    title: "Employee Data Processor",
    category: "Java · Data Processing",
    description:
      "A program that processes employee data using functional interfaces, collections, and streams.",
    tags: ["Java", "Streams", "Collections"],
  },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [headerVisible, setHeaderVisible] = useState(true);
  const [form, setForm] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("");
  const previousScroll = useRef(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScroll = window.scrollY;

      if (currentScroll < 80) {
        setHeaderVisible(true);
      } else if (currentScroll > previousScroll.current + 5) {
        setHeaderVisible(false);
        setMenuOpen(false);
      } else if (currentScroll < previousScroll.current - 5) {
        setHeaderVisible(true);
      }

      previousScroll.current = currentScroll;
    };

    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const updateField = (event) => {
    const { name, value } = event.target;

    setForm((current) => ({
      ...current,
      [name]: value,
    }));

    setErrors((current) => ({
      ...current,
      [name]: "",
    }));

    setStatus("");
  };

  const validateForm = () => {
    const nextErrors = {};

    if (!form.name.trim()) {
      nextErrors.name = "Please enter your name.";
    }

    if (!form.email.trim()) {
      nextErrors.email = "Please enter your email address.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      nextErrors.email = "Please enter a valid email address.";
    }

    if (!form.message.trim()) {
      nextErrors.message = "Please enter a message.";
    }

    return nextErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const nextErrors = validateForm();
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      setStatus("Please correct the highlighted fields.");
      return;
    }

    setStatus(
      "Your form passed validation. This demo does not send or store messages."
    );

    setForm({
      name: "",
      email: "",
      message: "",
    });
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="portfolio">
      <a className="skip-link" href="#main">
        Skip to content
      </a>

      <header
        className={`site-header ${
          headerVisible ? "header-visible" : "header-hidden"
        }`}
      >
        <nav className="navigation container" aria-label="Main navigation">
          <a className="brand" href="#home" onClick={closeMenu}>
            <span className="brand-mark">A</span>
            <span>Abdulqader</span>
          </a>

          <button
            className="menu-toggle"
            type="button"
            aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? "✕" : "☰"}
          </button>

          <div className={`nav-links ${menuOpen ? "nav-open" : ""}`}>
            <a href="#home" onClick={closeMenu}>Home</a>
            <a href="#about" onClick={closeMenu}>About</a>
            <a href="#projects" onClick={closeMenu}>Projects</a>
            <a href="#contact" onClick={closeMenu}>Contact</a>
            <a
              className="nav-social"
              href="https://github.com/Abdulqader-Mohammed-Qasem-Hasan-Nasr"
              target="_blank"
              rel="noreferrer"
            >
              GitHub ↗
            </a>
          </div>
        </nav>
      </header>

      <main id="main">
        <section className="hero section" id="home">
          <div className="container hero-grid">
            <div className="hero-copy">
              <p className="eyebrow">WELCOME TO MY PORTFOLIO</p>
              <h1>
                Building useful ideas
                <span> through code.</span>
              </h1>
              <p className="hero-description">
                I'm Abdulqader, a Computer Science student interested in
                software development, web technologies, and building practical
                digital solutions.
              </p>

              <div className="hero-actions">
                <a className="button button-primary" href="#projects">
                  Explore my work <span aria-hidden="true">↘</span>
                </a>
                <a className="button button-secondary" href="#contact">
                  Contact me
                </a>
              </div>

              <div className="social-links" aria-label="Social profiles">
                <a
                  href="https://github.com/Abdulqader-Mohammed-Qasem-Hasan-Nasr"
                  target="_blank"
                  rel="noreferrer"
                >
                  GitHub ↗
                </a>
                <a
                  href="https://www.linkedin.com/"
                  target="_blank"
                  rel="noreferrer"
                >
                  LinkedIn ↗
                </a>
              </div>
            </div>

            <div className="hero-visual">
              <div className="avatar" role="img" aria-label="Abdulqader's avatar">
                AN
              </div>
              <div className="avatar-caption">
                <span className="status-dot" />
                <span>Computer Science Student</span>
              </div>
              <div className="visual-note note-top">Curious mind.</div>
              <div className="visual-note note-bottom">Creative solutions.</div>
            </div>
          </div>
        </section>

        <section className="about section" id="about">
          <div className="container about-grid">
            <div>
              <p className="eyebrow">A LITTLE ABOUT ME</p>
              <h2>Learning today. Building for tomorrow.</h2>
            </div>

            <div className="about-content">
              <p>
                I'm studying Computer Science and developing my skills through
                hands-on projects. I enjoy understanding how software works,
                solving problems, and turning ideas into useful applications.
              </p>
              <p>
                My current interests include Java, React, databases, mobile
                development, and software design. I believe that consistent
                learning and thoughtful problem-solving are essential to
                becoming a better developer.
              </p>

              <div className="skills" aria-label="Technical skills">
                {["Java", "React", "JavaScript", "SQL", "Flutter", "Git"].map(
                  (skill) => (
                    <span className="skill" key={skill}>{skill}</span>
                  )
                )}
              </div>
            </div>
          </div>
        </section>

        <section className="projects section" id="projects">
          <div className="container">
            <div className="section-heading">
              <div>
                <p className="eyebrow">SELECTED WORK</p>
                <h2>Projects I've worked on</h2>
              </div>
              <p className="section-intro">
                A selection of practice projects that reflect my learning and
                development journey.
              </p>
            </div>

            <div className="project-grid">
              {projects.map((project) => (
                <article className="project-card" key={project.number}>
                  <div className="project-card-top">
                    <span className="project-number">{project.number}</span>
                    <span className="project-arrow" aria-hidden="true">↗</span>
                  </div>

                  <p className="project-category">{project.category}</p>
                  <h3>{project.title}</h3>
                  <p className="project-description">{project.description}</p>

                  <div className="project-tags">
                    {project.tags.map((tag) => (
                      <span key={tag}>{tag}</span>
                    ))}
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="contact section" id="contact">
          <div className="container contact-grid">
            <div className="contact-copy">
              <p className="eyebrow">LET'S CONNECT</p>
              <h2>Have an idea? Let's talk.</h2>
              <p>
                Have a question, an opportunity, or an idea for a project?
                Complete the form and I'll be glad to hear from you.
              </p>

              <a
                className="contact-email"
                href="https://github.com/Abdulqader-Mohammed-Qasem-Hasan-Nasr"
                target="_blank"
                rel="noreferrer"
              >
                Find me on GitHub ↗
              </a>
            </div>

            <form className="contact-form" onSubmit={handleSubmit} noValidate>
              <div className="form-field">
                <label htmlFor="name">Your name *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  autoComplete="name"
                  value={form.name}
                  onChange={updateField}
                  required
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? "name-error" : undefined}
                />
                {errors.name && (
                  <p className="field-error" id="name-error" role="alert">
                    {errors.name}
                  </p>
                )}
              </div>

              <div className="form-field">
                <label htmlFor="email">Email address *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  value={form.email}
                  onChange={updateField}
                  required
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? "email-error" : undefined}
                />
                {errors.email && (
                  <p className="field-error" id="email-error" role="alert">
                    {errors.email}
                  </p>
                )}
              </div>

              <div className="form-field">
                <label htmlFor="message">Your message *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={form.message}
                  onChange={updateField}
                  required
                  maxLength="1000"
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={
                    errors.message ? "message-error" : "message-help"
                  }
                />
                {errors.message ? (
                  <p className="field-error" id="message-error" role="alert">
                    {errors.message}
                  </p>
                ) : (
                  <p className="field-help" id="message-help">
                    Maximum 1000 characters.
                  </p>
                )}
              </div>

              <button className="button button-primary submit-button" type="submit">
                Validate and submit <span aria-hidden="true">→</span>
              </button>

              {status && (
                <p className="form-status" role="status" aria-live="polite">
                  {status}
                </p>
              )}
            </form>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-inner">
          <a className="brand footer-brand" href="#home">
            <span className="brand-mark">A</span>
            <span>Abdulqader</span>
          </a>
          <p>Designed and built with React.</p>
          <p>© {new Date().getFullYear()} Abdulqader. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
