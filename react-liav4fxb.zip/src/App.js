
import { useEffect, useState } from "react";
import "./App.css";

const projects = [
  {
    title: "Almoliki Grocery Manager",
    description:
      "A grocery management application for products, sales, debts, and inventory.",
    technologies: "Flutter • Dart • SQLite",
    link: "https://github.com/",
  },
  {
    title: "Employee Processor",
    description:
      "A Java application using functional interfaces and streams to process employee data.",
    technologies: "Java • OOP • Streams",
    link: "https://github.com/",
  },
  {
    title: "Personal Portfolio",
    description:
      "A responsive portfolio website showcasing my skills and programming projects.",
    technologies: "React • JavaScript • CSS",
    link: "https://github.com/",
  },
  {
    title: "Data Analysis",
    description:
      "Data analysis exercises using data cleaning, exploration, and visualization.",
    technologies: "Python • Pandas • Jupyter",
    link: "https://github.com/",
  },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showHeader, setShowHeader] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    let previousScroll = window.scrollY;

    function handleScroll() {
      const currentScroll = window.scrollY;

      setShowHeader(currentScroll < 50 || currentScroll < previousScroll);
      previousScroll = currentScroll;
    }

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  function handleSubmit(event) {
    event.preventDefault();

    if (!name.trim() || !email.trim() || !message.trim()) {
      setStatus("Please complete all fields.");
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setStatus("Please enter a valid email address.");
      return;
    }

    setStatus(
      "Thank you! The form is validated, but messages are not sent yet."
    );
  }

  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>

      <header className={`site-header ${showHeader ? "" : "hidden-header"}`}>
        <nav className="navbar container" aria-label="Main navigation">
          <a className="logo" href="#home" onClick={() => setMenuOpen(false)}>
            AN<span>.</span>
          </a>

          <button
            className="menu-toggle"
            type="button"
            aria-label="Toggle navigation"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? "✕" : "☰"}
          </button>

          <div className={`nav-links ${menuOpen ? "open" : ""}`}>
            {[
              ["Home", "home"],
              ["About", "about"],
              ["Projects", "projects"],
              ["Contact", "contact"],
            ].map(([label, id]) => (
              <a
                key={id}
                href={`#${id}`}
                onClick={() => setMenuOpen(false)}
              >
                {label}
              </a>
            ))}
          </div>
        </nav>
      </header>

      <main id="main">
        <section className="hero container" id="home">
          <div className="hero-content">
            <p className="eyebrow">COMPUTER SCIENCE STUDENT</p>
            <h1>
              Hello, I'm <span>Abdulqader</span>.
              <br />
              I build digital solutions.
            </h1>
            <p className="hero-description">
              I am a Computer Science student interested in software
              development, web technologies, and data analysis. I enjoy
              learning new skills and turning ideas into practical projects.
            </p>
            <div className="hero-actions">
              <a className="button primary-button" href="#projects">
                Explore my work
              </a>
              <a className="button secondary-button" href="#contact">
                Contact me
              </a>
            </div>
          </div>

          <div className="hero-visual" aria-label="Personal introduction">
            <div className="avatar">
              <span>AN</span>
            </div>
            <div className="floating-card">
              <span className="status-dot"></span>
              Learning. Building. Growing.
            </div>
          </div>
        </section>

        <section className="section container" id="about">
          <div className="section-heading">
            <p className="eyebrow">GET TO KNOW ME</p>
            <h2>About me</h2>
          </div>

          <div className="about-content">
            <p>
              I am pursuing a Bachelor's degree in Computer Science at the
              University of the People. My interests include Java
              programming, web development, Android applications, and
              database systems.
            </p>
            <p>
              My goal is to become a skilled software developer by building
              useful applications, strengthening my problem-solving
              abilities, and continuing to learn.
            </p>
          </div>

          <div className="skills">
            {[
              "Java",
              "JavaScript",
              "React",
              "Flutter",
              "SQL",
              "Python",
              "HTML & CSS",
              "Git & GitHub",
            ].map((skill) => (
              <span className="skill-tag" key={skill}>
                {skill}
              </span>
            ))}
          </div>
        </section>

        <section className="section projects-section" id="projects">
          <div className="container">
            <div className="section-heading">
              <p className="eyebrow">SELECTED WORK</p>
              <h2>My projects</h2>
              <p className="section-description">
                A selection of projects that reflect my learning and
                development journey.
              </p>
            </div>

            <div className="project-grid">
              {projects.map((project, index) => (
                <article className="project-card" key={project.title}>
                  <div className="project-number">
                    {String(index + 1).padStart(2, "0")}
                  </div>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <p className="project-tech">{project.technologies}</p>
                  <a
                    className="project-link"
                    href={project.link}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={`View ${project.title} on GitHub`}
                  >
                    View project ↗
                  </a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section container contact-section" id="contact">
          <div className="section-heading">
            <p className="eyebrow">LET'S CONNECT</p>
            <h2>Get in touch</h2>
            <p className="section-description">
              Have a question or an opportunity? Send me a message.
            </p>
          </div>

          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <label htmlFor="name">Your name</label>
            <input
              id="name"
              name="name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="Enter your name"
              required
            />

            <label htmlFor="email">Email address</label>
            <input
              id="email"
              name="email"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@example.com"
              required
            />

            <label htmlFor="message">Your message</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              value={message}
              onChange={(event) => setMessage(event.target.value)}
              placeholder="Write your message..."
              required
            />

            <button className="button primary-button" type="submit">
              Validate message
            </button>

            <p className="form-status" role="status" aria-live="polite">
              {status}
            </p>
          </form>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-content">
          <a className="logo" href="#home">
            AN<span>.</span>
          </a>
          <p>Designed and built by Abdulqader.</p>
          <a href="#home">Back to top ↑</a>
        </div>
      </footer>
    </>
  );
}

export default App;
