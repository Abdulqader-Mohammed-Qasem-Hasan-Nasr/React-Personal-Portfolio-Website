
import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.js";
import "./App.css";

const rootElement = document.getElementById("root");

if (!rootElement) {
  throw new Error('Could not find the HTML element with id="root".');
}

createRoot(rootElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
